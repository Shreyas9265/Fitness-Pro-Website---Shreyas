# 🏋️‍♂️ FitStrength Pro — AI-Generated Fitness Platform

An interactive **fitness and workout web app** designed with **Figma Make** and built using **React + TypeScript + Tailwind CSS**.
FitStrength Pro combines **AI-assisted design**, **modern UI components**, and **3D product visualization** to create an immersive experience for users exploring workouts and supplements.

🔗 **Figma Design Prototype:** [View FitStrength Pro in Figma](https://www.figma.com/make/EV7SLfkPHLqG5ppAfuCu25/Fitness-Workout-Website?fullscreen=1)

---

## 🚀 Features
- 💪 **Full-Body Strength Workouts** — Interactive exercise table with images, sets/reps, rest, and muscle groups
- 🛒 **E-commerce Section** — Add supplements and equipment to cart with animated celebration and toast alerts
- 🎨 **3D Product Cards** — Hover effects and product info powered by reusable UI components
- ⚙️ **Modular Components** — Built with shadcn-style UI and **lucide-react** icons
- 🌈 **AI-Generated UI** — Base design created via **Figma Make**, refined for responsiveness and accessibility

---

## 🧩 Tech Stack
- **Frontend:** React 18, TypeScript, Vite, Tailwind CSS
- **UI Components:** shadcn-style components, lucide-react
- **Animations & Notifications:** Sonner 2.0, Framer Motion
- **Design:** Figma Make (AI design generation)
- **Images:** Unsplash licensed assets

---

## 🛠️ Installation & Setup

```bash
# 1️⃣ Clone the repository
git clone https://github.com/<your-username>/fitstrength-pro.git
cd fitstrength-pro

# 2️⃣ Install dependencies
npm install

# 3️⃣ Run the development server
npm run dev

# 4️⃣ Open in browser
http://localhost:5173
```

---

## 📂 Project Structure
```
fitstrength-pro/
 ├── src/
 │   ├── components/           # Reusable UI components (cards, dialogs, cart, 3D view)
 │   ├── styles/               # Global CSS + Tailwind config
 │   ├── guidelines/           # UI and accessibility guidelines
 │   ├── App.tsx               # Main React app
 │   └── main.tsx
 ├── Attributions.md           # Licenses and credits
 ├── package.json
 └── README.md
```

---

## 📜 License & Credits
- UI components inspired by [shadcn/ui](https://ui.shadcn.com/) — MIT License【23†source】
- Photos from [Unsplash](https://unsplash.com) — Free to use under Unsplash License【23†source】

---

## ✨ About the Project
Created by **Shreyas Peddireddy** as a design-to-code showcase integrating **AI-generated UI**, **modern web frameworks**, and **interactive fitness experiences** inspired by **Figma’s collaborative design philosophy**.
